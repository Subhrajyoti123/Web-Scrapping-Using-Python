import requests

url = "http://127.0.0.1:8000/static/images/rosy3.jpg"

user = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36"

}

#print(dir(requests))

response = requests.get(url = url, headers = user)
pic = response.content

f = open("rosy3.jpg" , "wb")
f.write(pic)
#print(dir(response))
#print(response.status_code)
#print(response.headers)
#print(response.request.headers)
#print(type(response.content))
#print(response.content)
