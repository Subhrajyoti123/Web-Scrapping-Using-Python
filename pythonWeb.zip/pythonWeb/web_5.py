import requests
from bs4 import BeautifulSoup
import csv

def Extract(url):
    response = requests.get(url=url).content
    soup = BeautifulSoup(response , 'lxml')
    tag = soup.find('div' , {"id" : "mp-right"}) # now the the box showing in div tag in wikipwdia page
    #print(tag)
    h = tag.find_all("h2")
    conent = [span.text for span in h]
    #print(conent)
    #print(h)

    with open("wiki.csv" , "w") as csv_file:
        csv_write = csv.writer(csv_file)
        csv_write.writerow(conent)


Extract(url="https://en.wikipedia.org/wiki/Main_Page")