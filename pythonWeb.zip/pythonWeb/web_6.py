import requests
import re
import os

#insted of another folder of nature as per the lecture I have created lily as  a folder.

user = input("Enter the image name: ")

user_agent = {
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
}
url = f"https://www.google.co.in/search?q={user}&tbm=isch&ved=2ahUKEwih1qadwIKCAxVx3DgGHde9AIcQ2-cCegQIABAA&oq=+moon&gs_lcp=CgNpbWcQAzIKCAAQigUQsQMQQzIHCAAQigUQQzINCAAQigUQsQMQgwEQQzIKCAAQigUQsQMQQzIKCAAQigUQsQMQQzIKCAAQigUQsQMQQzIHCAAQigUQQzIKCAAQigUQsQMQQzIHCAAQigUQQzIHCAAQigUQQzoFCAAQgAQ6BggAEAcQHlCgDFj5EWCCGmgAcAB4AIAB1QeIAaoPkgELMC4zLjQtMS4wLjGYAQCgAQGqAQtnd3Mtd2l6LWltZ8ABAQ&sclient=img&ei=SlUxZaGJBfG44-EP1_uCuAg&bih=726&biw=1540"

response = requests.get(url = url ,headers = user_agent).text

#print(response)

pattern = '<img data-src=(\"https://[^> ]+\")'

images = re.findall(pattern, response)
print(f"Total Images : {len(images)}")
no_of_images = int(input("Number of images to be downloaded: "))

if images:
    if not os.path.exists(user):
        os.mkdir(user)
        os.chdir(user)
    else:
        os.chdir(user)

    if images:
        count=1

    for image in images[:no_of_images]:
        image_url = eval(image)
        response = requests.get(url=image_url).content
        #print(image_url)
        image_name = image_url.split('/')[-1]

        with open(f'moon{count}.jpg',"wb") as fp:
            fp.write(response)
            count += 1
